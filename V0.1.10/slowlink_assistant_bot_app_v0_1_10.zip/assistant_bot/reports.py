from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta

from .store import Stats


REPORT_NAMES = {
    "daily": "每日报告",
    "weekly": "每周报告",
    "monthly": "每月报告",
}

EMPTY_PERIOD_NAMES = {
    "daily": "昨日",
    "weekly": "上周",
    "monthly": "上月",
}


def format_display_time(value: str | datetime, reference: datetime) -> str:
    if value == "-":
        return "暂无"
    if isinstance(value, datetime):
        event_time = value
    else:
        try:
            event_time = datetime.fromisoformat(str(value))
        except ValueError:
            return str(value) if value else "暂无"

    if reference.tzinfo is not None:
        if event_time.tzinfo is None:
            event_time = event_time.replace(tzinfo=reference.tzinfo)
        else:
            event_time = event_time.astimezone(reference.tzinfo)

    if event_time.date() == reference.date():
        return event_time.strftime("%H:%M")
    return event_time.strftime("%m-%d %H:%M")


@dataclass(frozen=True)
class Period:
    kind: str
    start: datetime
    end: datetime

    @property
    def key(self) -> str:
        if self.kind == "monthly":
            return self.start.strftime("%Y-%m")
        if self.kind == "weekly":
            return self.start.strftime("%Y-W%W")
        return self.start.strftime("%Y-%m-%d")

    @property
    def label(self) -> str:
        if self.start.date() == self.end.date():
            return self.start.strftime("%Y-%m-%d")
        return f"{self.start:%Y-%m-%d}至{self.end:%Y-%m-%d}"


def start_of_day(now: datetime) -> datetime:
    return now.replace(hour=0, minute=0, second=0, microsecond=0)


def start_of_week(now: datetime) -> datetime:
    day = start_of_day(now)
    return day - timedelta(days=day.weekday())


def start_of_month(now: datetime) -> datetime:
    return now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)


def previous_month_start(now: datetime) -> datetime:
    current = start_of_month(now)
    last_day = current - timedelta(days=1)
    return start_of_month(last_day)


def manual_period(kind: str, now: datetime) -> Period:
    if kind == "daily":
        return Period(kind, start_of_day(now), now)
    if kind == "weekly":
        return Period(kind, start_of_week(now), now)
    if kind == "monthly":
        return Period(kind, start_of_month(now), now)
    raise ValueError(f"unknown report kind: {kind}")


def scheduled_period(kind: str, now: datetime) -> Period:
    anchor = now.replace(second=0, microsecond=0)
    if kind == "daily":
        end = start_of_day(anchor)
        return Period(kind, end - timedelta(days=1), end)
    if kind == "weekly":
        end = start_of_week(anchor)
        return Period(kind, end - timedelta(days=7), end)
    if kind == "monthly":
        end = start_of_month(anchor)
        return Period(kind, previous_month_start(anchor), end)
    raise ValueError(f"unknown report kind: {kind}")


def should_run_report(kind: str, now: datetime, hour: int, minute: int) -> bool:
    if now.hour != hour or now.minute != minute:
        return False
    if kind == "daily":
        return True
    if kind == "weekly":
        return now.weekday() == 0
    if kind == "monthly":
        return now.day == 1
    return False


def _failure_summary_text(failure_summary: list[dict] | None) -> str | None:
    if not failure_summary:
        return None
    parts = [f"{row.get('error')}×{int(row.get('count') or 0)}" for row in failure_summary if row.get("error")]
    if not parts:
        return None
    return "失败原因：" + "，".join(parts)


def format_report(
    kind: str,
    period: Period,
    stats: Stats,
    generated_at: datetime,
    failure_summary: list[dict] | None = None,
) -> str:
    title = REPORT_NAMES.get(kind, kind)
    period_name = EMPTY_PERIOD_NAMES.get(kind, "本周期")
    status = "正常" if stats.failure_count == 0 else "有异常"
    recent = format_display_time(stats.last_success_at, generated_at)
    if stats.total_count == 0:
        return "\n".join(
            [
                f"📊{title}",
                f"{period_name}暂无明显转发",
                "系统：待命中",
                "异常：0次",
            ]
        )

    lines = [
        f"📊{title}",
        f"{period_name}约转发{stats.success_count}条",
        f"系统：{status}",
        f"最近转发：{recent}",
        f"异常：{stats.failure_count}次",
    ]
    summary_text = _failure_summary_text(failure_summary)
    if summary_text:
        lines.append(summary_text.replace("失败原因：", "原因："))
    return "\n".join(lines)
