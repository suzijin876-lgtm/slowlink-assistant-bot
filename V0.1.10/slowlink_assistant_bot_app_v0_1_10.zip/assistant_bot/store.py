from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from threading import RLock


@dataclass(frozen=True)
class Stats:
    success_count: int
    failure_count: int
    total_count: int
    last_success_at: str
    last_failure: str


class EventStore:
    def __init__(self, path: str | Path):
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = RLock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self) -> None:
        with self._conn:
            self._conn.execute(
                """
                CREATE TABLE IF NOT EXISTS copy_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_chat_id TEXT NOT NULL,
                    source_title TEXT NOT NULL,
                    source_message_id INTEGER NOT NULL,
                    target_chat_id TEXT NOT NULL,
                    copied_message_id INTEGER,
                    ok INTEGER NOT NULL,
                    error TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    created_at_ts REAL NOT NULL
                )
                """
            )
            self._conn.execute(
                """
                CREATE TABLE IF NOT EXISTS sent_reports (
                    period_type TEXT NOT NULL,
                    period_key TEXT NOT NULL,
                    sent_at TEXT NOT NULL,
                    PRIMARY KEY (period_type, period_key)
                )
                """
            )
            self._conn.execute(
                """
                CREATE TABLE IF NOT EXISTS state (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )
                """
            )
            self._conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_copy_events_created_at_ts ON copy_events(created_at_ts)"
            )
            self._conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_copy_events_ok_created_at_ts ON copy_events(ok, created_at_ts)"
            )

    def _insert_event(
        self,
        source_chat_id: str,
        source_title: str,
        source_message_id: int,
        target_chat_id: str,
        copied_message_id: int | None,
        ok: bool,
        error: str,
        at: datetime,
    ) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                """
                INSERT INTO copy_events (
                    source_chat_id, source_title, source_message_id, target_chat_id,
                    copied_message_id, ok, error, created_at, created_at_ts
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    source_chat_id,
                    source_title,
                    int(source_message_id),
                    target_chat_id,
                    copied_message_id,
                    1 if ok else 0,
                    error,
                    at.isoformat(),
                    at.timestamp(),
                ),
            )

    def record_copy_success(
        self,
        source_chat_id: str,
        source_title: str,
        source_message_id: int,
        target_chat_id: str,
        copied_message_id: int | None,
        at: datetime,
    ) -> None:
        self._insert_event(source_chat_id, source_title, source_message_id, target_chat_id, copied_message_id, True, "", at)

    def record_copy_failure(
        self,
        source_chat_id: str,
        source_title: str,
        source_message_id: int,
        target_chat_id: str,
        error: str,
        at: datetime,
    ) -> None:
        self._insert_event(source_chat_id, source_title, source_message_id, target_chat_id, None, False, error[:500], at)

    def stats_between(self, start: datetime, end: datetime) -> Stats:
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT
                    SUM(CASE WHEN ok = 1 THEN 1 ELSE 0 END) AS success_count,
                    SUM(CASE WHEN ok = 0 THEN 1 ELSE 0 END) AS failure_count,
                    COUNT(*) AS total_count
                FROM copy_events
                WHERE created_at_ts >= ? AND created_at_ts < ?
                """,
                (start.timestamp(), end.timestamp()),
            ).fetchone()
            last_success = self._conn.execute(
                """
                SELECT created_at FROM copy_events
                WHERE ok = 1 AND created_at_ts >= ? AND created_at_ts < ?
                ORDER BY created_at_ts DESC LIMIT 1
                """,
                (start.timestamp(), end.timestamp()),
            ).fetchone()
            last_failure = self._conn.execute(
                """
                SELECT error FROM copy_events
                WHERE ok = 0 AND created_at_ts >= ? AND created_at_ts < ?
                ORDER BY created_at_ts DESC LIMIT 1
                """,
                (start.timestamp(), end.timestamp()),
            ).fetchone()
        success = int(rows["success_count"] or 0)
        failure = int(rows["failure_count"] or 0)
        return Stats(
            success_count=success,
            failure_count=failure,
            total_count=int(rows["total_count"] or 0),
            last_success_at=str(last_success["created_at"]) if last_success else "-",
            last_failure=str(last_failure["error"]) if last_failure else "-",
        )

    def failure_summary_between(self, start: datetime, end: datetime, limit: int = 3) -> list[dict]:
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT error, COUNT(*) AS count
                FROM copy_events
                WHERE ok = 0 AND created_at_ts >= ? AND created_at_ts < ? AND error != ''
                GROUP BY error
                ORDER BY count DESC, MAX(created_at_ts) DESC
                LIMIT ?
                """,
                (start.timestamp(), end.timestamp(), int(limit)),
            ).fetchall()
        return [{"error": str(row["error"]), "count": int(row["count"] or 0)} for row in rows]

    def prune_copy_events_before(self, cutoff: datetime) -> int:
        with self._lock, self._conn:
            cursor = self._conn.execute(
                "DELETE FROM copy_events WHERE created_at_ts < ?",
                (cutoff.timestamp(),),
            )
        return int(cursor.rowcount or 0)

    def health_check(self, at: datetime) -> bool:
        with self._lock, self._conn:
            self._conn.execute(
                """
                INSERT INTO state (key, value) VALUES ('health_check_at', ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value
                """,
                (at.isoformat(),),
            )
        return True

    def backup_database(self, at: datetime, keep_days: int = 7) -> str | None:
        if self.path == ":memory:":
            return None
        db_path = Path(self.path)
        backup_dir = db_path.parent / "backups"
        backup_dir.mkdir(parents=True, exist_ok=True)
        backup_path = backup_dir / f"assistant_{at:%Y%m%d}.sqlite3"
        with self._lock:
            backup_conn = sqlite3.connect(backup_path)
            try:
                self._conn.backup(backup_conn)
            finally:
                backup_conn.close()

        backups = sorted(backup_dir.glob("assistant_*.sqlite3"))
        for old_backup in backups[:-max(1, int(keep_days))]:
            try:
                old_backup.unlink()
            except OSError:
                pass
        return str(backup_path)

    def recent_events(self, limit: int = 8) -> list[dict]:
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT source_title, source_message_id, ok, error, created_at
                FROM copy_events
                ORDER BY created_at_ts DESC LIMIT ?
                """,
                (int(limit),),
            ).fetchall()
        return [dict(row) for row in rows]

    def was_report_sent(self, period_type: str, period_key: str) -> bool:
        with self._lock:
            row = self._conn.execute(
                "SELECT 1 FROM sent_reports WHERE period_type = ? AND period_key = ?",
                (period_type, period_key),
            ).fetchone()
        return row is not None

    def mark_report_sent(self, period_type: str, period_key: str, at: datetime) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                "INSERT OR IGNORE INTO sent_reports (period_type, period_key, sent_at) VALUES (?, ?, ?)",
                (period_type, period_key, at.isoformat()),
            )

    def get_state(self, key: str) -> str | None:
        with self._lock:
            row = self._conn.execute("SELECT value FROM state WHERE key = ?", (str(key),)).fetchone()
        if not row:
            return None
        return str(row["value"])

    def set_state(self, key: str, value: str) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                "INSERT INTO state (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                (str(key), str(value)),
            )

    def get_offset(self) -> int | None:
        with self._lock:
            row = self._conn.execute("SELECT value FROM state WHERE key = 'update_offset'").fetchone()
        if not row:
            return None
        try:
            return int(row["value"])
        except Exception:
            return None

    def set_offset(self, offset: int) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                "INSERT INTO state (key, value) VALUES ('update_offset', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                (str(int(offset)),),
            )

    def close(self) -> None:
        self._conn.close()
