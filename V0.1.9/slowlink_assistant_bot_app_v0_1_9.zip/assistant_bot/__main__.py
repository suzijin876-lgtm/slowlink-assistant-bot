from __future__ import annotations

import logging
import sys
import time
from datetime import datetime
from zoneinfo import ZoneInfo

from . import __version__
from .config import BotConfig, ConfigError
from .service import AssistantService
from .store import EventStore
from .telegram_api import TelegramAPI, TelegramAPIError


ALLOWED_UPDATES = ["message", "channel_post", "my_chat_member"]
LOG_TIMEZONE = ZoneInfo("Asia/Shanghai")


class ChinaTimeFormatter(logging.Formatter):
    def formatTime(self, record, datefmt=None):
        value = datetime.fromtimestamp(record.created, LOG_TIMEZONE)
        if datefmt:
            return value.strftime(datefmt)
        return value.strftime("%Y-%m-%d %H:%M:%S")


def setup_logging() -> None:
    handler = logging.StreamHandler()
    handler.setFormatter(ChinaTimeFormatter("[%(asctime)s] [%(levelname)s] %(message)s"))
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(logging.INFO)


def main() -> int:
    setup_logging()
    log = logging.getLogger("assistant_bot")
    try:
        config = BotConfig.load()
    except ConfigError as exc:
        log.error("配置错误：%s", exc)
        return 2

    store = EventStore(config.data_path)
    api = TelegramAPI(config.bot_token)
    service = AssistantService(config, api, store)

    try:
        api.delete_webhook(drop_pending_updates=config.startup_drop_pending_updates)
        me = api.get_me()
    except TelegramAPIError as exc:
        log.error("Telegram 初始化失败：%s", exc)
        return 3
    log.info("SlowLink Assistant 已启动：版本=%s", __version__)
    log.info("Bot 信息：账号=@%s 源频道=%d个 报表群=已配置", me.get("username", "unknown"), len(config.source_channel_refs))

    offset = store.get_offset()
    while True:
        try:
            updates = api.get_updates(offset=offset, timeout=config.poll_timeout, allowed_updates=ALLOWED_UPDATES)
            for update in updates:
                service.handle_update(update)
                offset = store.get_offset()
            service.run_due_reports()
            time.sleep(config.poll_interval)
        except KeyboardInterrupt:
            log.info("停止运行")
            return 0
        except Exception as exc:
            log.exception("主循环异常：%s", exc)
            time.sleep(5)


if __name__ == "__main__":
    sys.exit(main())
