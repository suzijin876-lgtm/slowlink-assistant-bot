from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any


class TelegramAPIError(RuntimeError):
    pass


class TelegramAPI:
    def __init__(self, token: str, base_url: str = "https://api.telegram.org"):
        self.token = token
        self.base_url = base_url.rstrip("/")

    def _request(self, method: str, payload: dict[str, Any], timeout: int = 35) -> Any:
        url = f"{self.base_url}/bot{self.token}/{method}"
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                body = resp.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise TelegramAPIError(f"{method} HTTP {exc.code}: {detail}") from exc
        except urllib.error.URLError as exc:
            raise TelegramAPIError(f"{method} network error: {exc}") from exc

        try:
            parsed = json.loads(body)
        except json.JSONDecodeError as exc:
            raise TelegramAPIError(f"{method} invalid JSON response") from exc
        if not parsed.get("ok"):
            raise TelegramAPIError(f"{method} failed: {parsed.get('description', parsed)}")
        return parsed.get("result")

    def delete_webhook(self, drop_pending_updates: bool = False):
        return self._request("deleteWebhook", {"drop_pending_updates": bool(drop_pending_updates)}, timeout=20)

    def get_me(self):
        return self._request("getMe", {}, timeout=20)

    def get_updates(self, offset: int | None, timeout: int, allowed_updates: list[str]):
        payload: dict[str, Any] = {"timeout": int(timeout), "allowed_updates": allowed_updates}
        if offset is not None:
            payload["offset"] = int(offset)
        return self._request("getUpdates", payload, timeout=int(timeout) + 10)

    def copy_message(self, chat_id, from_chat_id, message_id: int):
        return self._request(
            "copyMessage",
            {"chat_id": chat_id, "from_chat_id": from_chat_id, "message_id": int(message_id)},
            timeout=30,
        )

    def send_message(self, chat_id, text: str, disable_web_page_preview: bool = False):
        return self._request(
            "sendMessage",
            {"chat_id": chat_id, "text": text, "disable_web_page_preview": bool(disable_web_page_preview)},
            timeout=30,
        )

    def pin_chat_message(self, chat_id, message_id: int, disable_notification: bool = True):
        return self._request(
            "pinChatMessage",
            {"chat_id": chat_id, "message_id": int(message_id), "disable_notification": bool(disable_notification)},
            timeout=20,
        )

    def unpin_chat_message(self, chat_id, message_id: int):
        return self._request(
            "unpinChatMessage",
            {"chat_id": chat_id, "message_id": int(message_id)},
            timeout=20,
        )

    def get_chat_member(self, chat_id, user_id: int):
        return self._request(
            "getChatMember",
            {"chat_id": chat_id, "user_id": int(user_id)},
            timeout=20,
        )

    def leave_chat(self, chat_id):
        return self._request("leaveChat", {"chat_id": chat_id}, timeout=20)
