# 功能说明

当前版本：`0.1.9`

## 核心转发

- 监听 `.env` 中配置的 `SOURCE_CHANNEL_IDS`。
- 使用 Telegram Bot API 的 `copyMessage` 原样复制源频道消息。
- 新消息只发送到 `OWNER_USER_ID` 对应的个人私聊。
- 不做内容识别、不做去重、不生成新的 `t.me` 链接。
- 只统计 Bot 自己的复制成功和失败，不判断内容真假。

## 报表

- 固定报表群由 `REPORT_CHAT_ID` 指定。
- 报表群不会收到源频道的新消息。
- 每天 `00:00` 发送昨日报。
- 每周一 `00:00` 发送上周报。
- 每月 1 日 `00:00` 发送上月报。
- 报表发送后会尝试置顶。
- 新报表置顶成功后，会取消上一条报表置顶。
- 报表发送失败或置顶失败，会私聊提醒你。
- 空报表使用自然文案，例如“昨日暂无明显转发”。
- 失败报表会显示最多 3 个失败原因摘要。

## 命令

私聊可用命令：

```text
/help      查看命令
/status    查看运行状态
/report    查看当前概览
/recent    查看最近记录，可用 /recent 20
/check     自检
```

固定报表群可用命令：

```text
/report    查看当前概览
```

群里发送 `/start`、`/help`、`/id` 时，只会回复“此群已配置完成”，不会暴露群 ID。

## 权限和安全

- 私聊命令只允许 `OWNER_USER_ID` 使用。
- 固定报表群里只有你可以使用命令。
- 其他人私聊 Bot 会被忽略。
- Bot 被拉进非授权群组或频道，会自动退出。
- 同一个未授权群的退出提醒一小时最多发送一次，避免刷屏。
- `.env` 不应提交或打包到公开位置。

## 自检

`/check` 会检查：

- Bot 主循环是否能响应。
- SQLite 数据库是否可写。
- watchdog 状态文件是否近期更新。
- 源频道配置数量。
- 报表群权限是否正常。
- 今日转发和失败数量。
- 最近一次成功转发时间。

watchdog 状态含义：

- `守护：正常`：状态文件近期更新。
- `守护：异常`：状态文件不存在、读取失败或太久没更新。
- `守护：未知`：本地内存测试环境，没有真实状态文件。

## 数据和清理

- 使用 SQLite 保存转发记录、失败记录、报表发送状态和运行状态。
- 保存 Telegram update offset，重启后不会重复拉取旧更新。
- 自动清理 90 天前的转发记录。
- 每天自动备份 SQLite。
- 数据库备份保留最近 7 份。

## 稳定性

- Docker Compose 使用 `restart: always`。
- Docker healthcheck 会检查 Python 包和版本是否可加载。
- 独立 systemd watchdog 监控 `slowlink_assistant_bot` 容器 CPU。
- CPU 连续 4 次超过 85%，每次间隔 20 秒，watchdog 会重启 Bot 容器。
- 重启后有 600 秒冷却，避免反复重启。
- watchdog 会写中文日志和状态文件。
- watchdog 自动重启 Bot 后，会私聊提醒你。

## 日志

- Bot Docker 日志为中文。
- Bot Docker 日志使用北京时间。
- watchdog 日志为中文。
- watchdog 状态文件路径：`/opt/slowlink_assistant_bot/data/watchdog_status.txt`。
