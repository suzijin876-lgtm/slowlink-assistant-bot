from __future__ import annotations

import logging
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Callable, Any
from zoneinfo import ZoneInfo

from . import __version__
from .config import BotConfig, chat_ref_for_api, chat_username_ref, normalize_chat_ref
from .reports import (
    format_display_time,
    format_period_label,
    format_report,
    manual_period,
    report_name,
    report_period_field,
    scheduled_period,
    should_run_report,
)
from .store import EventStore


LOG = logging.getLogger(__name__)
COPY_FAILURE_ALERT_THRESHOLD = 3
EVENT_RETENTION_DAYS = 90
UNAUTHORIZED_CHAT_NOTICE_INTERVAL = timedelta(hours=1)
WATCHDOG_STATUS_MAX_AGE = timedelta(seconds=120)
LAST_REPORT_PIN_STATE_KEY = "last_report_pin_message_id"


class AssistantService:
    def __init__(self, config: BotConfig, api, store: EventStore, clock: Callable[[], datetime] | None = None):
        self.config = config
        self.api = api
        self.store = store
        self.tz = ZoneInfo(config.timezone)
        self.started_at = datetime.now(self.tz)
        self.clock = clock or (lambda: datetime.now(self.tz))
        self.consecutive_copy_failures = 0
        self.copy_failure_alert_active = False
        self.copy_failure_alert_times: dict[str, datetime] = {}
        self.unauthorized_chat_notice_times: dict[str, datetime] = {}
        self.last_cleanup_date: date | None = None
        self.last_backup_date: date | None = None

    def _now(self) -> datetime:
        now = self.clock()
        if now.tzinfo is None:
            return now.replace(tzinfo=self.tz)
        return now.astimezone(self.tz)

    def handle_update(self, update: dict[str, Any]) -> None:
        try:
            if "channel_post" in update:
                self._handle_channel_post(update["channel_post"])
            elif "message" in update:
                self._handle_message(update["message"])
            elif "my_chat_member" in update:
                self._handle_chat_member(update["my_chat_member"])
        finally:
            update_id = update.get("update_id")
            if update_id is not None:
                self.store.set_offset(int(update_id) + 1)

    def _chat_allowed_as_source(self, chat: dict[str, Any]) -> bool:
        refs = {normalize_chat_ref(chat)}
        username = chat_username_ref(chat)
        if username:
            refs.add(username)
        return bool(refs & self.config.source_channel_refs)

    def _handle_channel_post(self, message: dict[str, Any]) -> None:
        chat = message.get("chat") or {}
        if not self._chat_allowed_as_source(chat):
            return
        source_chat_id = str(chat.get("id") or "")
        source_title = str(chat.get("title") or chat.get("username") or source_chat_id)
        message_id = int(message.get("message_id") or 0)
        if not source_chat_id or not message_id:
            return

        try:
            result = self.api.copy_message(self.config.owner_user_id, int(source_chat_id), message_id)
            copied_id = int((result or {}).get("message_id") or 0) or None
            self.store.record_copy_success(source_chat_id, source_title, message_id, str(self.config.owner_user_id), copied_id, self._now())
            self._handle_copy_recovery(source_title, message_id)
            LOG.info("已复制频道消息：来源=%s 消息=%s", source_chat_id, message_id)
        except Exception as exc:
            error = str(exc)
            self.store.record_copy_failure(source_chat_id, source_title, message_id, str(self.config.owner_user_id), error, self._now())
            LOG.warning("复制消息失败：来源=%s 消息=%s 原因=%s", source_chat_id, message_id, error)
            self._handle_copy_failure(source_title, message_id, error)

    def _send_owner_notice(self, text: str) -> None:
        try:
            self.api.send_message(self.config.owner_user_id, text)
        except Exception:
            pass

    def _handle_copy_failure(self, source_title: str, message_id: int, error: str) -> None:
        self.consecutive_copy_failures += 1
        if self.consecutive_copy_failures < COPY_FAILURE_ALERT_THRESHOLD or self.copy_failure_alert_active:
            return
        now = self._now()
        error_key = error[:120]
        last_alert = self.copy_failure_alert_times.get(error_key)
        if last_alert and now - last_alert < timedelta(hours=1):
            return
        self.copy_failure_alert_active = True
        self.copy_failure_alert_times[error_key] = now
        self._send_owner_notice(
            "\n".join(
                [
                    "⚠️转发连续失败",
                    f"连续：{self.consecutive_copy_failures}次",
                    f"来源：{source_title}",
                    f"消息：#{message_id}",
                    f"原因：{error}",
                ]
            )
        )

    def _handle_copy_recovery(self, source_title: str, message_id: int) -> None:
        should_notice = self.copy_failure_alert_active
        self.consecutive_copy_failures = 0
        self.copy_failure_alert_active = False
        if not should_notice:
            return
        self._send_owner_notice(
            "\n".join(
                [
                    "✅转发已恢复",
                    f"来源：{source_title}",
                    f"消息：#{message_id}",
                ]
            )
        )

    def _handle_message(self, message: dict[str, Any]) -> None:
        chat = message.get("chat") or {}
        chat_type = str(chat.get("type") or "")
        from_user = message.get("from") or {}
        user_id = int(from_user.get("id") or 0)
        text = str(message.get("text") or "").strip()

        if chat_type == "private":
            if user_id != self.config.owner_user_id:
                return
            if text.startswith("/"):
                self._handle_owner_command(text)
            return

        if chat_type in {"group", "supergroup"}:
            chat_id = normalize_chat_ref(chat)
            if chat_id != self.config.report_chat_id and self.config.unauthorized_group_action == "leave":
                self._leave_unauthorized_chat(chat, chat_id)
                return
            if chat_id == self.config.report_chat_id:
                self._handle_report_group_command(chat_id, user_id, text)

    def _handle_report_group_command(self, chat_id: str, user_id: int, text: str) -> None:
        if user_id != self.config.owner_user_id or not text.startswith("/"):
            return
        command = text.split()[0].split("@")[0].lower()
        target_chat = chat_ref_for_api(chat_id)
        if command == "/report":
            self.send_current_report(target_chat)
        elif command in {"/start", "/help", "/id"}:
            self.api.send_message(target_chat, self.group_ready_text(), disable_web_page_preview=True)

    def _handle_chat_member(self, update: dict[str, Any]) -> None:
        chat = update.get("chat") or {}
        chat_type = str(chat.get("type") or "")
        if chat_type not in {"group", "supergroup", "channel"}:
            return
        chat_id = normalize_chat_ref(chat)
        allowed = chat_id == self.config.report_chat_id or self._chat_allowed_as_source(chat)
        if not allowed and self.config.unauthorized_group_action == "leave":
            self._leave_unauthorized_chat(chat, chat_id)

    def _leave_unauthorized_chat(self, chat: dict[str, Any], chat_id: str) -> None:
        title = str(chat.get("title") or chat.get("username") or "未知群组")
        now = self._now()
        try:
            self.api.leave_chat(chat_ref_for_api(chat_id))
            if self._should_send_unauthorized_chat_notice(chat_id, now):
                self._send_owner_notice(f"⚠️已退出未授权群\n名称：{title}")
        except Exception as exc:
            if self._should_send_unauthorized_chat_notice(chat_id, now):
                self._send_owner_notice(f"⚠️未授权群退出失败\n名称：{title}\n原因：{exc}")

    def _should_send_unauthorized_chat_notice(self, chat_id: str, now: datetime) -> bool:
        last_notice = self.unauthorized_chat_notice_times.get(chat_id)
        if last_notice and now - last_notice < UNAUTHORIZED_CHAT_NOTICE_INTERVAL:
            return False
        self.unauthorized_chat_notice_times[chat_id] = now
        return True

    def _handle_owner_command(self, text: str) -> None:
        command = text.split()[0].split("@")[0].lower()
        if command in {"/start", "/help"}:
            self.api.send_message(self.config.owner_user_id, self.help_text(), disable_web_page_preview=True)
        elif command == "/status":
            self.api.send_message(self.config.owner_user_id, self.status_text(), disable_web_page_preview=True)
        elif command == "/report":
            self.send_current_report()
        elif command == "/recent":
            self.api.send_message(self.config.owner_user_id, self.recent_text(self._recent_limit_from_command(text)), disable_web_page_preview=True)
        elif command == "/check":
            self.api.send_message(self.config.owner_user_id, self.check_text(), disable_web_page_preview=True)
        else:
            self.api.send_message(self.config.owner_user_id, "未知命令，发送 /help 查看可用功能。")

    def group_ready_text(self) -> str:
        return "✅此群已配置完成\n可用命令：/report"

    def help_text(self) -> str:
        return "\n".join(
            [
                "SlowLink Assistant Bot",
                "/status 查看运行状态",
                "/report 查看当前报告",
                "/recent 查看最近记录",
                "/check 自检",
            ]
        )

    def _format_duration(self, start: datetime, end: datetime) -> str:
        seconds = max(0, int((end - start).total_seconds()))
        days, rem = divmod(seconds, 86400)
        hours, rem = divmod(rem, 3600)
        minutes = rem // 60
        if days:
            return f"{days}天{hours}小时"
        if hours:
            return f"{hours}小时{minutes}分"
        return f"{minutes}分"

    def _recent_limit_from_command(self, text: str) -> int:
        parts = text.split()
        if len(parts) < 2:
            return 8
        try:
            limit = int(parts[1])
        except ValueError:
            return 8
        return max(1, min(30, limit))

    def _report_group_status_text(self) -> str:
        try:
            me = self.api.get_me()
            member = self.api.get_chat_member(self.config.report_chat_id_for_api, int(me.get("id") or 0))
        except Exception:
            return "异常"
        status = str(member.get("status") or "")
        if status in {"creator", "administrator"}:
            return "已配置"
        if status == "member" and member.get("can_send_messages") is not False:
            return "已配置"
        return "异常"

    def status_text(self) -> str:
        now = self._now()
        today = manual_period("daily", now)
        stats = self.store.stats_between(today.start, today.end)
        recent = format_display_time(stats.last_success_at, now)
        return "\n".join(
            [
                "✅运行状态",
                f"版本：{__version__}",
                f"源频道：{len(self.config.source_channel_refs)}个",
                f"报表群：{self._report_group_status_text()}",
                f"运行：{self._format_duration(self.started_at, now)}",
                f"今日：转发{stats.success_count}条/失败{stats.failure_count}条",
                f"最近：{recent}",
            ]
        )

    def check_text(self) -> str:
        now = self._now()
        today = manual_period("daily", now)
        stats = self.store.stats_between(today.start, today.end)
        try:
            db_ok = self.store.health_check(now)
        except Exception:
            db_ok = False
        recent = format_display_time(stats.last_success_at, now)
        return "\n".join(
            [
                "✅自检完成",
                "Bot：正常",
                f"数据库：{'正常' if db_ok else '异常'}",
                f"守护：{self._watchdog_status_text(now)}",
                f"源频道：{len(self.config.source_channel_refs)}个",
                f"报表群：{self._report_group_status_text()}",
                f"今日：转发{stats.success_count}条/失败{stats.failure_count}条",
                f"最近：{recent}",
            ]
        )

    def _watchdog_status_text(self, now: datetime) -> str:
        if self.store.path == ":memory:":
            return "未知"
        status_path = Path(self.store.path).parent / "watchdog_status.txt"
        try:
            values = {}
            for line in status_path.read_text(encoding="utf-8").splitlines():
                if "=" not in line:
                    continue
                key, value = line.split("=", 1)
                values[key.strip()] = value.strip()
            updated_at_ts = float(values.get("updated_at_ts") or "")
        except Exception:
            return "异常"
        age = now.timestamp() - updated_at_ts
        if 0 <= age <= WATCHDOG_STATUS_MAX_AGE.total_seconds():
            return "正常"
        return "异常"

    def recent_text(self, limit: int = 8) -> str:
        rows = self.store.recent_events(limit)
        if not rows:
            return "🧾最近记录\n暂无转发记录"
        lines = ["🧾最近记录"]
        for row in rows:
            ok = "转发成功" if int(row.get("ok") or 0) == 1 else "转发失败"
            event_time = format_display_time(str(row.get("created_at") or ""), self._now())
            detail = str(row.get("error") or "")
            suffix = f"｜{detail}" if detail else ""
            lines.append(f"{event_time}｜{ok}｜{row.get('source_title')}#{row.get('source_message_id')}{suffix}")
        return "\n".join(lines)

    def send_manual_report(self, kind: str) -> None:
        now = self._now()
        period = manual_period(kind, now)
        stats = self.store.stats_between(period.start, period.end)
        summary = self.store.failure_summary_between(period.start, period.end)
        self.api.send_message(self.config.owner_user_id, format_report(kind, period, stats, now, summary), disable_web_page_preview=True)

    def current_report_text(self) -> str:
        now = self._now()
        today = manual_period("daily", now)
        stats = self.store.stats_between(today.start, today.end)
        summary = self.store.failure_summary_between(today.start, today.end)
        recent = format_display_time(stats.last_success_at, now)
        status = "正常" if stats.failure_count == 0 else "有失败"
        if stats.total_count == 0:
            return "\n".join(
                [
                    "📌当前概览",
                    "今日暂无明显转发",
                    "系统：待命中",
                    "异常：0次",
                ]
            )
        lines = [
            "📌当前概览",
            f"今日转发{stats.success_count}条",
            f"最近：{recent}",
            f"系统：{status if status == '正常' else '有异常'}",
            f"异常：{stats.failure_count}次",
        ]
        if summary:
            parts = [f"{row.get('error')}×{int(row.get('count') or 0)}" for row in summary]
            lines.append("原因：" + "，".join(parts))
        return "\n".join(lines)

    def send_current_report(self, chat_id=None) -> None:
        target_chat = self.config.owner_user_id if chat_id is None else chat_id
        self.api.send_message(target_chat, self.current_report_text(), disable_web_page_preview=True)

    def run_due_reports(self, now: datetime | None = None) -> None:
        now = (now or self._now()).astimezone(self.tz)
        self._backup_database(now)
        self._cleanup_old_events(now)
        for kind in ("daily", "weekly", "monthly"):
            if not should_run_report(kind, now, self.config.report_hour, self.config.report_minute):
                continue
            period = scheduled_period(kind, now)
            if self.store.was_report_sent(kind, period.key):
                continue
            stats = self.store.stats_between(period.start, period.end)
            summary = self.store.failure_summary_between(period.start, period.end)
            text = format_report(kind, period, stats, now, summary)
            title = report_name(kind)
            period_field = report_period_field(kind)
            period_label = format_period_label(period)
            try:
                result = self.api.send_message(self.config.report_chat_id_for_api, text, disable_web_page_preview=True)
            except Exception as exc:
                LOG.warning("%s发送失败：%s=%s 原因=%s", title, period_field, period_label, exc)
                self._send_owner_notice(f"⚠️{title}发送失败\n{period_field}：{period_label}\n原因：{exc}")
                continue
            message_id = int((result or {}).get("message_id") or 0)
            if message_id:
                try:
                    self.api.pin_chat_message(self.config.report_chat_id_for_api, message_id, disable_notification=True)
                    self._unpin_previous_report(message_id)
                except Exception as exc:
                    LOG.warning("%s置顶失败：%s=%s 原因=%s", title, period_field, period_label, exc)
                    self._send_owner_notice(f"⚠️{title}置顶失败\n{period_field}：{period_label}\n原因：{exc}")
            self.store.mark_report_sent(kind, period.key, now)
            LOG.info(
                "%s发送完成：%s=%s 转发=%s条 异常=%s次",
                title,
                period_field,
                period_label,
                stats.success_count,
                stats.failure_count,
            )

    def _unpin_previous_report(self, current_message_id: int) -> None:
        previous_message_id = self.store.get_state(LAST_REPORT_PIN_STATE_KEY)
        self.store.set_state(LAST_REPORT_PIN_STATE_KEY, str(int(current_message_id)))
        if not previous_message_id:
            return
        try:
            previous = int(previous_message_id)
        except ValueError:
            return
        if previous == int(current_message_id):
            return
        try:
            self.api.unpin_chat_message(self.config.report_chat_id_for_api, previous)
        except Exception as exc:
            LOG.warning("旧报表取消置顶失败：消息=%s 原因=%s", previous, exc)

    def _backup_database(self, now: datetime) -> None:
        if self.last_backup_date == now.date():
            return
        try:
            backup_path = self.store.backup_database(now)
            self.last_backup_date = now.date()
            if backup_path:
                LOG.info("数据库备份完成：路径=%s", backup_path)
        except Exception as exc:
            LOG.warning("数据库备份失败：原因=%s", exc)
            self._send_owner_notice(f"⚠️数据库备份失败\n原因：{exc}")

    def _cleanup_old_events(self, now: datetime) -> None:
        if self.last_cleanup_date == now.date():
            return
        cutoff = now - timedelta(days=EVENT_RETENTION_DAYS)
        deleted = self.store.prune_copy_events_before(cutoff)
        self.last_cleanup_date = now.date()
        if deleted:
            LOG.info("已清理旧记录：数量=%s 截止日期=%s", deleted, cutoff.date())
